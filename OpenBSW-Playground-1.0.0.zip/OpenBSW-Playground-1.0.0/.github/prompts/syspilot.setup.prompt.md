---
agent: syspilot.setup
---
